function main

clear; clc;

experiments('adult-a');
% experiments('w8a');
% experiments('real-sim');

% experiments('mnist1vs7');
% experiments('mnist7vs9');
% experiments('mnist4vs9');
% experiments('rcv1_full')
